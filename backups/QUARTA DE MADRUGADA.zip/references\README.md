Pasta de referências visuais.
